﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColourMesh
{
    public static Mesh ColourTriangles(Mesh mesh, Color[] triangleColours)
    {
        Vector3[] vertices = mesh.vertices;
        int[] triangles = mesh.triangles;

        Vector3[] newVertrices = new Vector3[triangles.Length];
        int[] newTriangles = new int[triangles.Length];

        Color[] colours = new Color[newVertrices.Length];

        for (int i = 0; i < triangles.Length; i += 3)
        {
            newVertrices[i] = vertices[triangles[i]];
            newVertrices[i + 1] = vertices[triangles[i + 1]];
            newVertrices[i + 2] = vertices[triangles[i + 2]];

            newTriangles[i] = i;
            newTriangles[i + 1] = i + 1;
            newTriangles[i + 2] = i + 2;

            colours[i] = triangleColours[i / 3];
        }

        return new Mesh { vertices = newVertrices, triangles = newTriangles, colors = colours };
    }
}
