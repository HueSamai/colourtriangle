﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshScript : MonoBehaviour
{
    private void Awake()
    {
        Mesh testMesh = new Mesh
        {
            vertices = new Vector3[] { new Vector3(-10, 0, -10), new Vector3(10, 10, 10), new Vector3(0, 0, 0),
            new Vector3(-10, 20, -10), new Vector3(10, 30, 10), new Vector3(0, 20, 0)},
            triangles = new int[] { 0, 1, 2, 0, 4, 5 }
        };

        Color[] colours = new Color[] { Color.red, Color.blue };

        GetComponent<MeshFilter>().sharedMesh = ColourMesh.ColourTriangles(testMesh, colours);
    }
}
